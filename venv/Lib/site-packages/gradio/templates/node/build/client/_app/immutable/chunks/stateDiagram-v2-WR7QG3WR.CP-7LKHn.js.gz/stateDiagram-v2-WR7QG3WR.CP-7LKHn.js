import{s as a,S as t,b as r,a as s}from"./chunk-4IRHCMPZ.DARru7w7.js";import{_ as i}from"./mermaid.core.CiFBvUky.js";var _={parser:a,get db(){return new t(2)},renderer:r,styles:s,init:i(e=>{e.state||(e.state={}),e.state.arrowMarkerAbsolute=e.arrowMarkerAbsolute},"init")};export{_ as diagram};
//# sourceMappingURL=stateDiagram-v2-WR7QG3WR.CP-7LKHn.js.map
