import{P as c,a as r}from"./mermaid-parser.core.bmtpdoSc.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-W2GHVCYJ.D6HXo0tK.js.map
