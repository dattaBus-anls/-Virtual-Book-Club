import{s as t}from"../chunks/client.D2UMFAPF.js";export{t as start};
//# sourceMappingURL=start.DYqe7hkZ.js.map
