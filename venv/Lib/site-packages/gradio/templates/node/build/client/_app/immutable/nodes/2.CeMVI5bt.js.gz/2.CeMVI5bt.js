import{Z as e,_ as n}from"../chunks/2.D-CDO7_W.js";export{e as component,n as universal};
//# sourceMappingURL=2.CeMVI5bt.js.map
